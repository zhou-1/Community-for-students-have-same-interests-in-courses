from django.apps import AppConfig


class MatchappConfig(AppConfig):
    name = 'matchApp'
